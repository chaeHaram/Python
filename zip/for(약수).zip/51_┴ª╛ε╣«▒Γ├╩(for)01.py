N = int(input("수 입력 : "))

if N % 2 == 0:
    print(N, "은 짝수 입니다.")
else:
    print(N,"은 홀수 입니다.")