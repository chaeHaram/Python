N = int(input("수 입력 : "))

li = []
for i in range(1, N+1):
    li.append(i)
print(li)

