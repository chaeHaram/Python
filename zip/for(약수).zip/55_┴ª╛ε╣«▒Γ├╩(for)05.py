N = int(input("수 입력 : "))

li = []
if N % 2 == 1:
    li.append(N)
print(li)
