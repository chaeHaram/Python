N = int(input("수 입력 : "))

if N % 3 == 0:
    print(N, "은 3의 배수입니다.")
