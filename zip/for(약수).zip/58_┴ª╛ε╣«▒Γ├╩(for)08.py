N = int(input("수 입력 : "))

for i in range(1, N+1):
    if i % 3 == 0:
        print(i, "은 3의 배수입니다.")