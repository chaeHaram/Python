# 수를 입력받고 (N) 짝수, 홀수를 판별하는 프로그램
N = int(input("수 입력 :"))

if N % 2 == 0:
    print("짝수")
else:
    print("홀수")
    