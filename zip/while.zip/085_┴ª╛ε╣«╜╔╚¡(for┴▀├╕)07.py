# 수를 입력받고 (N) N 단을 출력하는 프로그램

N = int(input("단 입력 : "))

for i in range(1,10):
    print(N,"X",i,"=",N*i)

