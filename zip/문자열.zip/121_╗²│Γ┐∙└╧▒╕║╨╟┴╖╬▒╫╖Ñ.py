# 생년월일을 입력받고, 년, 월, 일로 나눠서 출력하세요.

birth = input("생년월일을 입력하세요 : ")
print("년 :",birth[0:2])
print("월 :",birth[2:4])
print("일 :",birth[4:6])
