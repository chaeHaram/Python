# 문자열 내의 필요없는! 공백을 제거할 때 사용합니다.
st = '             hello             '
print(st.strip())
print(st.lstrip())
print(st.rstrip())