# 문자열 안에 특정 글자를 셀 때 사용합니다.
st = 'hello world my name is han'
print(st.count('l'))
