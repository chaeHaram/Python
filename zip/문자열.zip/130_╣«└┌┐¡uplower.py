print('helLO'.upper()) # 대문자 전환
print('HeLLo'.lower()) # 소문자 전환
# 이 또한, 특정 단어를 검출할 때 자주 사용됩니다.

# Rollin' rollin' rollin' 과 같은 같은 단어지만,
# 영어 특성상 같은 단어라도 앞에 나오면 
# 대문자이기때문에 
# lower 를 써줍니다.